from django.contrib import admin
from .models import Category, DifficultyLevel, Question, Choice, QuizSession, Answer

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)

@admin.register(DifficultyLevel)
class DifficultyLevelAdmin(admin.ModelAdmin):
    list_display = ('name', 'value', 'description')
    list_filter = ('value',)
    ordering = ('value',)

class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 4
    fields = ('text', 'is_correct')

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('get_question_preview', 'category', 'difficulty')
    list_filter = ('category', 'difficulty')
    search_fields = ('text',)
    inlines = [ChoiceInline]
    
    def get_question_preview(self, obj):
        return obj.text[:50] + "..." if len(obj.text) > 50 else obj.text
    get_question_preview.short_description = "Question"

@admin.register(Choice)
class ChoiceAdmin(admin.ModelAdmin):
    list_display = ('text', 'question', 'is_correct')
    list_filter = ('is_correct', 'question__category')
    search_fields = ('text', 'question__text')

class AnswerInline(admin.TabularInline):
    model = Answer
    extra = 0
    readonly_fields = ('question', 'selected_choice', 'is_correct')
    can_delete = False
    
    def has_add_permission(self, request, obj=None):
        return False

@admin.register(QuizSession)
class QuizSessionAdmin(admin.ModelAdmin):
    list_display = ('get_session_info', 'user', 'start_time', 'end_time', 'score', 'total_questions', 'score_percentage')
    list_filter = ('user', 'start_time', 'category', 'difficulty')
    readonly_fields = ('start_time', 'score_percentage')
    inlines = [AnswerInline]
    
    def get_session_info(self, obj):
        return f"Session #{obj.id}"
    get_session_info.short_description = "Session"
    
    def score_percentage(self, obj):
        return f"{obj.score_percentage}%"
    score_percentage.short_description = "Score %"

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('session', 'question_preview', 'selected_choice', 'is_correct')
    list_filter = ('is_correct', 'session__user', 'session__start_time')
    search_fields = ('question__text', 'selected_choice__text')
    readonly_fields = ('session', 'question', 'selected_choice', 'is_correct')
    
    def question_preview(self, obj):
        return obj.question.text[:30] + "..." if len(obj.question.text) > 30 else obj.question.text
    question_preview.short_description = "Question"
    
    def has_add_permission(self, request):
        return False