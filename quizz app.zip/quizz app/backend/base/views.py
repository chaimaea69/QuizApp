from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.http import Http404

from .forms import UserRegisterForm, QuizSelectionForm, AnswerForm
from .models import Category, DifficultyLevel, Question, Choice, QuizSession, Answer

import random

def index(request):
    """Page d'accueil"""
    num_questions = Question.objects.count()
    num_categories = Category.objects.count()
    num_sessions = QuizSession.objects.count()
    
    context = {
        'num_questions': num_questions,
        'num_categories': num_categories,
        'num_sessions': num_sessions,
    }
    return render(request, 'quiz/index.html', context)

def register(request):
    """Vue pour l'inscription des utilisateurs"""
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Compte créé pour {username}! Vous pouvez maintenant vous connecter.')
            return redirect('base:login')  # Changed from 'registration:login' to 'base:login'
    else:
        form = UserRegisterForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def profile(request):
    """Vue pour afficher le profil de l'utilisateur"""
    user = request.user
    sessions = QuizSession.objects.filter(user=user).order_by('-start_time')[:5]
    
    # Statistiques
    total_sessions = QuizSession.objects.filter(user=user).count()
    total_questions_answered = sum(session.total_questions for session in QuizSession.objects.filter(user=user))
    correct_answers = sum(session.score for session in QuizSession.objects.filter(user=user))
    
    avg_score = 0
    if total_questions_answered > 0:
        avg_score = (correct_answers / total_questions_answered) * 100
    
    context = {
        'user': user,
        'sessions': sessions,
        'total_sessions': total_sessions,
        'total_questions_answered': total_questions_answered,
        'avg_score': avg_score,
    }
    return render(request, 'quiz/profile.html', context)

@login_required
def quiz_selection(request):
    """View for quiz selection page"""
    form = QuizSelectionForm()
    return render(request, 'quiz/quiz_selection.html', {'form': form})

@login_required
def start_quiz(request):
    """Start a new quiz session"""
    if request.method == 'POST':
        form = QuizSelectionForm(request.POST)
        if form.is_valid():
            category = form.cleaned_data['category']
            difficulty = form.cleaned_data['difficulty']
            num_questions = form.cleaned_data['num_questions']
            
            # Create new quiz session
            session = QuizSession.objects.create(
                user=request.user,
                category=category,
                difficulty=difficulty,
                total_questions=num_questions,
                start_time=timezone.now()
            )
            
            # Get random questions based on criteria
            questions = Question.objects.filter(
                category=category,
                difficulty=difficulty
            ).order_by('?')[:num_questions]
            
            # Add questions to session
            session.questions.set(questions)
            
            # Initialize question index in session
            request.session[f'quiz_{session.id}_current_question'] = 0
            return redirect('base:quiz_question', session_id=session.id)
    
    return redirect('base:quiz_selection')

@login_required
def quiz_question(request, session_id):
    """Vue pour afficher une question et recueillir la réponse"""
    session = get_object_or_404(QuizSession, id=session_id, user=request.user)
    questions = list(session.questions.all())
    
    # Verify if there are questions in the session
    if not questions:
        messages.error(request, "Aucune question n'est disponible pour ce quiz.")
        return redirect('base:quiz_selection')
    
    # Get current question index from session
    question_index = request.session.get(f'quiz_{session_id}_current_question', 0)
    
    # Check if we've reached the end of the quiz
    if question_index >= len(questions):
        session.end_time = timezone.now()
        session.save()
        return redirect('base:quiz_result', session_id=session_id)
    
    current_question = questions[question_index]
    
    if request.method == 'POST':
        selected_choice_id = request.POST.get('choice')
        if selected_choice_id:
            choice = get_object_or_404(Choice, id=selected_choice_id)
            # Record the answer
            Answer.objects.create(
                session=session,
                question=current_question,
                selected_choice=choice,
                is_correct=choice.is_correct
            )
            if choice.is_correct:
                session.score += 1
                session.save()
            
            # Move to next question
            request.session[f'quiz_{session_id}_current_question'] = question_index + 1
            return redirect('base:quiz_question', session_id=session_id)
    
    context = {
        'session': session,
        'question': current_question,
        'choices': current_question.choices.all(),
        'progress': {
            'current': question_index + 1,
            'total': len(questions),
            'percentage': ((question_index + 1) / len(questions)) * 100
        }
    }
    return render(request, 'quiz/quiz_question.html', context)

@login_required
def quiz_result(request, session_id):
    """Vue pour afficher les résultats d'un quiz"""
    session = get_object_or_404(QuizSession, id=session_id, user=request.user)
    
    # Si la session n'est pas terminée, la terminer
    if not session.end_time:
        session.end_time = timezone.now()
        session.save()
    
    # Récupérer les réponses
    answers = Answer.objects.filter(session=session).select_related('question', 'selected_choice')
    
    # Nettoyer les données de session
    session_key = f'quiz_session_{session_id}'
    if session_key in request.session:
        del request.session[session_key]
    
    context = {
        'session': session,
        'answers': answers,
        'score_percentage': session.score_percentage,
    }
    return render(request, 'quiz/quiz_result.html', context)

@login_required
def history(request):
    """View for displaying user's quiz history"""
    user_sessions = QuizSession.objects.filter(user=request.user).order_by('-start_time')
    return render(request, 'quiz/history.html', {'sessions': user_sessions})

@login_required
def session_detail(request, session_id):
    """Vue pour afficher les détails d'une session spécifique"""
    session = get_object_or_404(QuizSession, id=session_id, user=request.user)
    answers = Answer.objects.filter(session=session).select_related('question', 'selected_choice')
    
    context = {
        'session': session,
        'answers': answers,
    }
    return render(request, 'quiz/session_detail.html', context)