from django.db import models
from django.contrib.auth.models import User

class Category(models.Model):
    """Modèle pour les catégories de questions"""
    name = models.CharField(max_length=100, verbose_name="Nom de la catégorie")
    description = models.TextField(blank=True, verbose_name="Description")
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = "Catégorie"
        verbose_name_plural = "Catégories"

class DifficultyLevel(models.Model):
    """Modèle pour les niveaux de difficulté"""
    name = models.CharField(max_length=50, verbose_name="Nom du niveau")
    value = models.PositiveIntegerField(unique=True, verbose_name="Valeur numérique")
    description = models.TextField(blank=True, verbose_name="Description")
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = "Niveau de difficulté"
        verbose_name_plural = "Niveaux de difficulté"
        ordering = ['value']

class Question(models.Model):
    """Modèle pour les questions de quiz"""
    text = models.TextField(verbose_name="Texte de la question")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, verbose_name="Catégorie")
    difficulty = models.ForeignKey(DifficultyLevel, on_delete=models.CASCADE, verbose_name="Difficulté")
    explanation = models.TextField(blank=True, verbose_name="Explication")
    
    def __str__(self):
        return self.text[:50]
    
    class Meta:
        verbose_name = "Question"
        verbose_name_plural = "Questions"

class Choice(models.Model):
    """Modèle pour les choix de réponses"""
    question = models.ForeignKey(Question, related_name='choices', on_delete=models.CASCADE)
    text = models.CharField(max_length=255, verbose_name="Texte du choix")
    is_correct = models.BooleanField(default=False, verbose_name="Réponse correcte")
    
    def __str__(self):
        return self.text
    
    class Meta:
        verbose_name = "Choix"
        verbose_name_plural = "Choix"

class QuizSession(models.Model):
    """Modèle pour les sessions de quiz"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Utilisateur")
    start_time = models.DateTimeField(auto_now_add=True, verbose_name="Heure de début")
    end_time = models.DateTimeField(null=True, blank=True, verbose_name="Heure de fin")
    score = models.IntegerField(default=0, verbose_name="Score")
    total_questions = models.IntegerField(verbose_name="Nombre total de questions")
    category = models.ForeignKey(
        Category, 
        on_delete=models.SET_NULL,  # Changed from CASCADE to SET_NULL
        null=True,  # Allow null values
        blank=True,  # Allow blank in forms
        verbose_name="Catégorie"
    )
    difficulty = models.ForeignKey(
        DifficultyLevel,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Difficulté"
    )
    questions = models.ManyToManyField(Question, verbose_name="Questions")  # Champ ajouté
    
    def __str__(self):
        return f"Session de {self.user.username} du {self.start_time.strftime('%d/%m/%Y %H:%M')}"
    
    @property
    def score_percentage(self):
        if self.total_questions > 0:
            return (self.score / self.total_questions) * 100
        return 0
    
    class Meta:
        verbose_name = "Session de quiz"
        verbose_name_plural = "Sessions de quiz"

class Answer(models.Model):
    """Modèle pour les réponses données par l'utilisateur"""
    session = models.ForeignKey(QuizSession, related_name='answers', on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    selected_choice = models.ForeignKey(Choice, on_delete=models.CASCADE)
    is_correct = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Réponse de {self.session.user.username} à la question {self.question.id}"
    
    class Meta:
        verbose_name = "Réponse"
        verbose_name_plural = "Réponses"