from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Category, DifficultyLevel

class UserRegisterForm(UserCreationForm):
    """Formulaire d'inscription pour les utilisateurs"""
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=False, help_text='Optionnel')
    last_name = forms.CharField(max_length=30, required=False, help_text='Optionnel')

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']

class QuizSelectionForm(forms.Form):
    """Formulaire pour sélectionner un quiz par catégorie et niveau de difficulté"""
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=False,
        empty_label="Toutes les catégories",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    difficulty = forms.ModelChoiceField(
        queryset=DifficultyLevel.objects.all().order_by('value'),
        required=False,
        empty_label="Tous les niveaux",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    num_questions = forms.IntegerField(
        min_value=5,
        max_value=20,
        initial=10,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )

class AnswerForm(forms.Form):
    """Formulaire dynamique pour répondre aux questions"""
    def __init__(self, *args, **kwargs):
        choices = kwargs.pop('choices', None)
        super(AnswerForm, self).__init__(*args, **kwargs)
        
        if choices:
            self.fields['choice'] = forms.ModelChoiceField(
                queryset=choices,
                widget=forms.RadioSelect(),
                empty_label=None,
                required=True,
                label=''
            )