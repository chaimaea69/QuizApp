from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'base'

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('profile/', views.profile, name='profile'),
    path('quiz-selection/', views.quiz_selection, name='quiz_selection'),
    path('history/', views.history, name='history'),
    path('start-quiz/', views.start_quiz, name='start_quiz'),
    path('quiz/<int:session_id>/', views.quiz_question, name='quiz_question'),
]